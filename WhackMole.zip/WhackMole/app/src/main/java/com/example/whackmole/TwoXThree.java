package com.example.whackmole;

import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.content.Intent;


public class TwoXThree extends AppCompatActivity{
    private TextView score,time;
    private int count,pos;
    private Random rand;
    private boolean clicked = false;
    private ImageView img1,img2,img3,img4,img5,img6;
    private long lastClickTime = 0,currentTime,timeElapsed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_xthree);

        count = 0;
        rand = new Random();
        pos = rand.nextInt(6);
        score = findViewById(R.id.score);
        time = findViewById(R.id.timer);


        img1 = (ImageView) findViewById(R.id.dig1);
        img2 = (ImageView) findViewById(R.id.dig2);
        img3 = (ImageView) findViewById(R.id.dig3);
        img4 = (ImageView) findViewById(R.id.dig4);
        img5 = (ImageView) findViewById(R.id.dig5);
        img6 = (ImageView) findViewById(R.id.dig6);


        img1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img1.setVisibility(view.INVISIBLE);
                clicked = true;
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=(long)0;
                lastClickTime=currentTime;
            }
        });

        img2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img2.setVisibility(view.INVISIBLE);
                clicked = true;
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=(long)0;
                lastClickTime=currentTime;
            }
        });

        img3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img3.setVisibility(view.INVISIBLE);
                clicked = true;
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=(long)0;
                lastClickTime=currentTime;
            }
        });

        img4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img4.setVisibility(view.INVISIBLE);
                clicked = true;
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=(long)0;
                lastClickTime=currentTime;
            }
        });

        img5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img5.setVisibility(view.INVISIBLE);
                clicked = true;
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=(long)0;
                lastClickTime=currentTime;
            }
        });

        img6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count++;
                score.setText("Score:" + count);
                img6.setVisibility(view.INVISIBLE);
                clicked = true;
            }
        });

        new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                time.setText("Time:"+millisUntilFinished / 1000);
                currentTime= SystemClock.elapsedRealtime();
                timeElapsed=currentTime-lastClickTime;
                if(clicked||timeElapsed>=2000){
                    for(int i = 1;i <= 6;i++)
                    {
                        Resources r = getResources();
                        int obj = r.getIdentifier(("dig" + i),"id",getPackageName());
                        ImageView img = findViewById(obj);
                        img.setVisibility(View.INVISIBLE);
                    }
                    pos=rand.nextInt(6);
                    pos++;
                    Resources r = getResources();
                    int obj = r.getIdentifier(("dig" + pos),"id",getPackageName());
                    ImageView img = findViewById(obj);
                    img.setVisibility(View.VISIBLE);
                    lastClickTime=currentTime;
                    clicked = false;
                }
            }

            public void onFinish() {
                Intent intent = new Intent(TwoXThree.this, Final.class);
                intent.putExtra("score",""+count);
                startActivity(intent);
            }
        }.start();
    }
}
